﻿using System.Web;
using System.Web.Mvc;

namespace _U21475009_HW03_
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
