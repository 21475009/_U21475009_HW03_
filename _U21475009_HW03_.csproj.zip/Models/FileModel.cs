﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.ComponentModel.DataAnnotations;
namespace _U21475009_HW03_.Models
{
    public class FileModel
    {
        [Display(Name ="File Name")]

        public string FileName { get; set; }

    }

    
}    

   